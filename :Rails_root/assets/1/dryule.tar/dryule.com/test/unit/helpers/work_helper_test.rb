require 'test_helper'

class WorkHelperTest < ActionView::TestCase
end

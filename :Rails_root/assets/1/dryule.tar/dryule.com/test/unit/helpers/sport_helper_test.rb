require 'test_helper'

class SportHelperTest < ActionView::TestCase
end

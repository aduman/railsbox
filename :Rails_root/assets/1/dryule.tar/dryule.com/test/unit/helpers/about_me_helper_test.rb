require 'test_helper'

class AboutMeHelperTest < ActionView::TestCase
end

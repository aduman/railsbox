class AboutMeController < ApplicationController
end

class PokerController < ApplicationController
  def index
  end

end

class SportController < ApplicationController
  def index
  end

end

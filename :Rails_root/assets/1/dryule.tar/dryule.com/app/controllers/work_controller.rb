class WorkController < ApplicationController
  def index
  end

end
